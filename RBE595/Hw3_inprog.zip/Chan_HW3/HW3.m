t = [1:11];
beta = linspace(0.5,1,11);
figure;
for i = 1:11
    betaP(i) = (beta(i)/(1-beta(i)));
    fplot(@(x) betaP(i)*x);
    hold on
    xlim([0 10])
    ylim([0 100])
end
xlabel('v(t)');
ylabel('u(t)');

